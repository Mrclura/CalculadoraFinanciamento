# Calculadora de Financiamento
Calculadora financeira para cáculo de juros e financimento, para a matéria de Programação Funcional da UFABC (2024.2).

O relatório com maiores explicações e detalhes se encontra na raiz do projeto, com o nome de "Projeto 1 Programação Funcional.pdf".

## Integrantes

* Fernanda Felix da Silva - 11201921613
* Gabriela Tamura Makibara - 11201920430
* Maurício Lura Segura - 11201720106
